var xiaokang = new xkTool("https://ae01.alicdn.com/kf/H21b5f6b8496141a1979a33666e1074d9x.jpg");
var xiaokangnue = new xkTool("transparent");